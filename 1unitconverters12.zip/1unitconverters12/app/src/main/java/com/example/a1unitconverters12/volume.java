package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class volume extends AppCompatActivity {


        private EditText volumeInput;
        private Button literToMilliliterButton;
        private Button milliliterToLiterButton;
        private TextView resultTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_volume);

            volumeInput = findViewById(R.id.volumeInput);
            literToMilliliterButton = findViewById(R.id.literToMilliliterButton);
            milliliterToLiterButton = findViewById(R.id.milliliterToLiterButton);
            resultTextView = findViewById(R.id.resultTextView);

            literToMilliliterButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertLiterToMilliliter();
                }
            });

            milliliterToLiterButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertMilliliterToLiter();
                }
            });
        }

        private void convertLiterToMilliliter() {
            try {
                double liter = Double.parseDouble(volumeInput.getText().toString());
                double milliliter = liter * 1000.0; // 1 liter = 1000 milliliters
                resultTextView.setText(String.format("%.2f liters = %.2f milliliters", liter, milliliter));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input. Please enter a valid number.");
            }
        }

        private void convertMilliliterToLiter() {
            try {
                double milliliter = Double.parseDouble(volumeInput.getText().toString());
                double liter = milliliter / 1000.0; // 1 milliliter = 0.001 liter
                resultTextView.setText(String.format("%.2f milliliters = %.2f liters", milliliter, liter));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input. Please enter a valid number.");
            }
        }
    }
