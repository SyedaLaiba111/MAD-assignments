package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Area extends AppCompatActivity {




        private EditText timeInput;
        private Button squareMToSquareKmButton;
        private Button squareKmToSquareMButton;
        private TextView resultTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_area);

            // Initialize UI elements
            timeInput = findViewById(R.id.timeInput);
            squareMToSquareKmButton = findViewById(R.id.minutesToSecondsButton);
            squareKmToSquareMButton = findViewById(R.id.secondsToMinutesButton);
            resultTextView = findViewById(R.id.resultTextView);

            // Set click listeners for conversion buttons
            squareMToSquareKmButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertSquareMToSquareKm();
                }
            });

            squareKmToSquareMButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertSquareKmToSquareM();
                }
            });
        }

        private void convertSquareMToSquareKm() {
            try {
                double squareMeters = Double.parseDouble(timeInput.getText().toString());
                double squareKilometers = squareMeters / 1000000.0; // 1 square kilometer = 1,000,000 square meters
                resultTextView.setText(String.format("%.4f square km", squareKilometers));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input");
            }
        }

        private void convertSquareKmToSquareM() {
            try {
                double squareKilometers = Double.parseDouble(timeInput.getText().toString());
                double squareMeters = squareKilometers * 1000000.0; // 1 square kilometer = 1,000,000 square meters
                resultTextView.setText(String.format("%.4f square meters", squareMeters));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input");
            }
        }
    }
