package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class waight_and_mass extends AppCompatActivity {

    private EditText weightInput;
    private TextView resultTextView;
    private Button kilogramToGramButton;
    private Button gramToKilogramButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waight_and_mass);

        weightInput = findViewById(R.id.weightInput);
        resultTextView = findViewById(R.id.resultTextView);
        kilogramToGramButton = findViewById(R.id.kilogramToGramButton);
        gramToKilogramButton = findViewById(R.id.gramToKilogramButton);

        kilogramToGramButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convertKilogramToGram();
            }
        });

        gramToKilogramButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convertGramToKilogram();
            }
        });
    }

    private void convertKilogramToGram() {
        try {
            double kilogram = Double.parseDouble(weightInput.getText().toString());
            double grams = kilogram * 1000; // 1 kilogram = 1000 grams
            resultTextView.setText(String.format("%.2f kilograms = %.2f grams", kilogram, grams));
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input");
        }
    }

    private void convertGramToKilogram() {
        try {
            double grams = Double.parseDouble(weightInput.getText().toString());
            double kilograms = grams / 1000; // 1 gram = 0.001 kilograms
            resultTextView.setText(String.format("%.2f grams = %.2f kilograms", grams, kilograms));
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input");
        }
    }
}
