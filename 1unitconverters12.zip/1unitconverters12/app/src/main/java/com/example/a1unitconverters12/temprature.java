package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class temprature extends AppCompatActivity {

    @Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temprature);

        EditText temperatureInput = findViewById(R.id.timeInput);
        Button celsiusToFahrenheitButton = findViewById(R.id.minutesToSecondsButton);
        Button fahrenheitToCelsiusButton = findViewById(R.id.secondsToMinutesButton);
        TextView resultTextView = findViewById(R.id.resultTextView);

        celsiusToFahrenheitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String celsiusText = temperatureInput.getText().toString();
                if (!celsiusText.isEmpty()) {
                    try {
                        double celsius = Double.parseDouble(celsiusText);
                        double fahrenheit = (celsius * 9/5) + 32;
                        resultTextView.setText(celsius + "°C is equal to " + fahrenheit + "°F");
                    } catch (NumberFormatException e) {
                        resultTextView.setText("Invalid input");
                    }
                } else {
                    resultTextView.setText("Please enter a value");
                }
            }
        });

        fahrenheitToCelsiusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Implement Fahrenheit to Celsius conversion logic here
                String fahrenheitText = temperatureInput.getText().toString();
                if (!fahrenheitText.isEmpty()) {
                    try {
                        double fahrenheit = Double.parseDouble(fahrenheitText);
                        double celsius = (fahrenheit - 32) * 5/9;
                        resultTextView.setText(fahrenheit + "°F is equal to " + celsius + "°C");
                    } catch (NumberFormatException e) {
                        resultTextView.setText("Invalid input");
                    }
                } else {
                    resultTextView.setText("Please enter a value");
                }
            }
        });
    }
}
