package com.example.a1unitconverters12;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.relativelayout);

        RelativeLayout converterBox7 = findViewById(R.id.converterBox7);

        // Set an OnClickListener for converterBox7
        converterBox7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, age_calculator.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "age calculator open", Toast.LENGTH_SHORT).show();


            }
        });
        RelativeLayout converterBox3 = findViewById(R.id.converterBox3);

        // Set an OnClickListener for converterBox7
        converterBox3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Area.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "area convertor is open", Toast.LENGTH_SHORT).show();

            }
        });

        RelativeLayout converterBox = findViewById(R.id.converterBox);

        converterBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CURRUNCY.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "curruncy convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox2 = findViewById(R.id.converterBox2);

        // Set an OnClickListener for converterBox7
        converterBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, lenght.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "lenght convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox1 = findViewById(R.id.converterBox1);

        // Set an OnClickListener for converterBox7
        converterBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, temprature.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "temprature convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox6 = findViewById(R.id.converterBox6);

        // Set an OnClickListener for converterBox7
        converterBox6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, time_belgium.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "belgium time convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox4 = findViewById(R.id.converterBox4);

        // Set an OnClickListener for converterBox7
        converterBox4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, volume.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "volum convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox5 = findViewById(R.id.converterBox5);

        // Set an OnClickListener for converterBox7
        converterBox5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, waight_and_mass.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "weight and mass convertor is open", Toast.LENGTH_SHORT).show();

            }
        });
        RelativeLayout converterBox8 = findViewById(R.id.converterBox8);
        converterBox8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this , bmi.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this,"bmi is opening",Toast.LENGTH_SHORT).show();
            }
        });

    }
    }