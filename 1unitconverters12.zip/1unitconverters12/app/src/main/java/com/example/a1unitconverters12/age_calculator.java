package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import java.util.Calendar;

public class age_calculator extends AppCompatActivity {


    private DatePicker datePicker;
    private Button calculateButton;
    private TextView resultLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_calculator);

        datePicker = findViewById(R.id.datePicker);
        calculateButton = findViewById(R.id.calculateButton);
        resultLabel = findViewById(R.id.resultLabel);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAge();
            }
        });
    }

    private void calculateAge() {
        try {
            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1; // Month is zero-based, so add 1.
            int year = datePicker.getYear();

            // Get the current date
            Calendar currentDate = Calendar.getInstance();
            int currentYear = currentDate.get(Calendar.YEAR);
            int currentMonth = currentDate.get(Calendar.MONTH) + 1; // Month is zero-based, so add 1.
            int currentDay = currentDate.get(Calendar.DAY_OF_MONTH);

            // Calculate age
            int age = currentYear - year;

            // Adjust age if the birthday hasn't occurred yet this year
            if (currentMonth < month || (currentMonth == month && currentDay < day)) {
                age--;
            }

            String ageResult = "Your age is: " + age + " years";
            resultLabel.setText(ageResult);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error calculating age.", Toast.LENGTH_SHORT).show();
        }
    }
}