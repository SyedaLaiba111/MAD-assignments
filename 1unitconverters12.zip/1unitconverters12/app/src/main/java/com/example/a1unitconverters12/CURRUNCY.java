
package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CURRUNCY extends AppCompatActivity {




        private EditText timeInput;
        private Button dollerToPkrButton;
        private Button pkrToDollerButton;
        private TextView resultTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_curruncy);

            // Initialize UI elements
            timeInput = findViewById(R.id.timeInput);
            dollerToPkrButton = findViewById(R.id.minutesToSecondsButton);
            pkrToDollerButton = findViewById(R.id.secondsToMinutesButton);
            resultTextView = findViewById(R.id.resultTextView);

            // Set click listeners for conversion buttons
            dollerToPkrButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertDollerToPkr();
                }
            });

            pkrToDollerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertPkrToDoller();
                }
            });
        }

        private void convertDollerToPkr() {
            try {
                double dollers = Double.parseDouble(timeInput.getText().toString());
                double pkr = dollers * 296.42; // Replace YOUR_CONVERSION_RATE with the actual rate
                resultTextView.setText(String.format("%.2f PKR", pkr));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input");
            }
        }

        private void convertPkrToDoller() {
            try {
                double pkr = Double.parseDouble(timeInput.getText().toString());
                double dollers = pkr / 296.42; // Replace YOUR_CONVERSION_RATE with the actual rate
                resultTextView.setText(String.format("%.2f USD", dollers));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input");
            }
        }
    }
