package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class lenght extends AppCompatActivity {


        private EditText lengthInput;
        private Button metersToCentimetersButton;
        private Button centimetersToMetersButton;
        private TextView resultTextView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_lenght);

            lengthInput = findViewById(R.id.timeInput);
            metersToCentimetersButton = findViewById(R.id.minutesToSecondsButton);
            centimetersToMetersButton = findViewById(R.id.secondsToMinutesButton);
            resultTextView = findViewById(R.id.resultTextView);

            metersToCentimetersButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertMetersToCentimeters();
                }
            });

            centimetersToMetersButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    convertCentimetersToMeters();
                }
            });
        }

        private void convertMetersToCentimeters() {
            try {
                double meters = Double.parseDouble(lengthInput.getText().toString());
                double centimeters = meters * 100.0; // 1 meter = 100 centimeters
                resultTextView.setText(String.format("%.2f meters = %.2f centimeters", meters, centimeters));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input. Please enter a valid number.");
            }
        }

        private void convertCentimetersToMeters() {
            try {
                double centimeters = Double.parseDouble(lengthInput.getText().toString());
                double meters = centimeters / 100.0; // 1 centimeter = 0.01 meters
                resultTextView.setText(String.format("%.2f centimeters = %.2f meters", centimeters, meters));
            } catch (NumberFormatException e) {
                resultTextView.setText("Invalid input. Please enter a valid number.");
            }
        }
    }

