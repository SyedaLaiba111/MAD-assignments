package com.example.a1unitconverters12;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class time_belgium extends AppCompatActivity {

    private EditText timeInput;
    private Button belgiumToPakistanButton;
    private Button pakistanToBelgiumButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_belgium);

        timeInput = findViewById(R.id.timeInput);
        belgiumToPakistanButton = findViewById(R.id.belgiumToPakistanButton);
        pakistanToBelgiumButton = findViewById(R.id.pakistanToBelgiumButton);
        resultTextView = findViewById(R.id.resultTextView);

        belgiumToPakistanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertBelgiumToPakistan();
            }
        });

        pakistanToBelgiumButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertPakistanToBelgium();
            }
        });
    }

    private void convertBelgiumToPakistan() {
        try {
            // Get the time value entered by the user
            double belgiumTime = Double.parseDouble(timeInput.getText().toString());

            // Perform the Belgium to Pakistan time conversion
            // For example, you can assume a 3-hour time difference between Belgium and Pakistan
            double pakistanTime = belgiumTime - 3;

            // Display the result in resultTextView
            resultTextView.setText("Pakistan Time: " + pakistanTime + " hours");
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input. Please enter a valid number.");
        }
    }

    private void convertPakistanToBelgium() {
        try {
            // Get the time value entered by the user
            double pakistanTime = Double.parseDouble(timeInput.getText().toString());

            // Perform the Pakistan to Belgium time conversion
            // For example, you can assume a 3-hour time difference between Belgium and Pakistan
            double belgiumTime = pakistanTime + 3;

            // Display the result in resultTextView
            resultTextView.setText("Belgium Time: " + belgiumTime + " hours");
        } catch (NumberFormatException e) {
            resultTextView.setText("Invalid input. Please enter a valid number.");
        }
    }
}
