package com.example.tripmate_paperustion;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Loginform extends AppCompatActivity {

    private EditText nameEditText;
    private EditText passwordEditText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginform);

        dbHelper = new DatabaseHelper(this);
        nameEditText = findViewById(R.id.editTextName); // Assuming you have EditText fields in your XML layout
        passwordEditText = findViewById(R.id.editTextPassword); // Change the IDs accordingly

        Button loginButton = findViewById(R.id.login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Login code
                String name = nameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(password)) {
                    // Check if name or password is empty
                    Toast.makeText(Loginform.this, "Please enter both name and password", Toast.LENGTH_SHORT).show();
                } else if (dbHelper.checkUser(name, password)) {
                    // Successful login
                    // Navigate to the HomeActivity
                    Intent intent = new Intent(Loginform.this, HomeActivity.class);
                    startActivity(intent);
                } else {
                    // Login failed, show an error message
                    Toast.makeText(Loginform.this, "Wrong username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
