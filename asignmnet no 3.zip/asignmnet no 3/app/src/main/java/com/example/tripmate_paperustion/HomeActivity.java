package com.example.tripmate_paperustion;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize RecyclerView and populate it with data (you'll need to create the adapter)
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create an adapter and set it to the RecyclerView
        TipAdapter adapter = new TipAdapter(getTipsData()); // Replace with your data source
        recyclerView.setAdapter(adapter);
    }

    // Replace this with your actual data source
    private List<Tip> getTipsData() {
        List<Tip> tips = new ArrayList<>();
        tips.add(new Tip("Lahore", "Lahore is the city of wonders with a rich history of over a millennium. Lahore the 2nd largest city of Pakistan and is capital of province Punjab."));
        tips.add(new Tip("Islamabad" , "Islamabad has a reputation of being a thriving, business-minded capital that lies in the centre of Pakistan's growing urbanized scene. The white marble Faisal Mosque, which is an important landmark of the city one of the largest mosques in the world, is a central point of tourists as is the bustling Jinnah Market."));
        // Add more tips here
        return tips;
    }
}
