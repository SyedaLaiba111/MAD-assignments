package com.example.assignnment4;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class LocationListAdapter extends RecyclerView.Adapter<LocationListAdapter.ViewHolder> {

        private final Context context;
        private final List<LocationEntry> locationEntries;
        private final OnLocationItemClickListener itemClickListener;

        public LocationListAdapter(Context context, List<LocationEntry> locationEntries, OnLocationItemClickListener itemClickListener) {
            this.context = context;
            this.locationEntries = locationEntries;
            this.itemClickListener = itemClickListener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.location_list_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            LocationEntry locationEntry = locationEntries.get(position);

            holder.locationName.setText(locationEntry.getName());
            holder.locationDescription.setText(locationEntry.getDescription());
            holder.locationImage.setImageBitmap(locationEntry.getPicture());

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    itemClickListener.onEditClick(position);
                }
            });
        }

        @Override
        public int getItemCount() {
            return locationEntries.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            private final TextView locationName;
            private final TextView locationDescription;
            private final ImageView locationImage;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                locationName = itemView.findViewById(R.id.locationName);
                locationDescription = itemView.findViewById(R.id.locationDescription);
                locationImage = itemView.findViewById(R.id.locationImage);
            }
        }

        public interface OnLocationItemClickListener {
            void onEditClick(int position);
            void onUpdateClick(int position);
            void onDeleteClick(int position);
        }
    }
