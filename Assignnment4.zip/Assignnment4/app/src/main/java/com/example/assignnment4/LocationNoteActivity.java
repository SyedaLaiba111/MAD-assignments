package com.example.assignnment4;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class LocationNoteActivity extends Activity {

    private EditText etLocationName, etLocationDescription;
    private ImageView imageLocationPicture;
    private Button btnAddPicture, btnSaveNote, btnEdit, btnUpdate, btnDelete;

    private Bitmap locationPicture;
    private List<LocationEntry> locationEntries;
    private LocationListAdapter locationListAdapter;
    private RecyclerView recyclerView;

    private boolean isEditMode = false;
    private int selectedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_note_entry);

        etLocationName = findViewById(R.id.etLocationName);
        etLocationDescription = findViewById(R.id.etLocationDescription);
        imageLocationPicture = findViewById(R.id.imageLocationPicture);
        btnAddPicture = findViewById(R.id.btnAddPicture);
        btnSaveNote = findViewById(R.id.btnSaveLocationNote);
        btnEdit = findViewById(R.id.btnEdit);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        recyclerView = findViewById(R.id.recyclerViewLocations);

        locationEntries = new ArrayList<>();
        locationListAdapter = new LocationListAdapter(this, locationEntries, new LocationListAdapter.OnLocationItemClickListener() {
            @Override
            public void onEditClick(int position) {
                selectedPosition = position;
                isEditMode = true;
                LocationEntry locationEntry = locationEntries.get(position);
                etLocationName.setText(locationEntry.getName());
                etLocationDescription.setText(locationEntry.getDescription());
                imageLocationPicture.setImageBitmap(locationEntry.getPicture());
                showEditButtons(true);
            }

            @Override
            public void onUpdateClick(int position) {
                LocationEntry locationEntry = locationEntries.get(position);
                locationEntry.setName(etLocationName.getText().toString().trim());
                locationEntry.setDescription(etLocationDescription.getText().toString().trim());
                locationEntry.setPicture(locationPicture);
                locationListAdapter.notifyDataSetChanged();
                clearInputFields();
                showEditButtons(false);
                isEditMode = false;
                selectedPosition = -1;
                Toast.makeText(LocationNoteActivity.this, "Location note updated", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDeleteClick(int position) {
                locationEntries.remove(position);
                locationListAdapter.notifyDataSetChanged();
                clearInputFields();
                showEditButtons(false);
                isEditMode = false;
                selectedPosition = -1;
                Toast.makeText(LocationNoteActivity.this, "Location note deleted", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView.setAdapter(locationListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        btnAddPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 1);
            }
        });

        btnSaveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEditMode) {
                    String locationName = etLocationName.getText().toString().trim();
                    String locationDescription = etLocationDescription.getText().toString().trim();

                    if (!locationName.isEmpty() && !locationDescription.isEmpty()) {
                        if (locationPicture != null) {
                            if (selectedPosition == -1) {
                                LocationEntry locationEntry = new LocationEntry(locationName, locationDescription, locationPicture);
                                locationEntries.add(locationEntry);
                            } else {
                                LocationEntry locationEntry = locationEntries.get(selectedPosition);
                                locationEntry.setName(locationName);
                                locationEntry.setDescription(locationDescription);
                                locationEntry.setPicture(locationPicture);
                            }
                            locationListAdapter.notifyDataSetChanged();
                            clearInputFields();
                            Toast.makeText(LocationNoteActivity.this, "Location note saved", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LocationNoteActivity.this, "Please add a picture", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(LocationNoteActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        initEditUpdateDeleteButtonListeners();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            if (extras != null) {
                locationPicture = (Bitmap) extras.get("data");
                imageLocationPicture.setImageBitmap(locationPicture);
            }
        }
    }

    private void clearInputFields() {
        etLocationName.setText("");
        etLocationDescription.setText("");
        imageLocationPicture.setImageResource(android.R.color.transparent);
        locationPicture = null;
    }

    private void initEditUpdateDeleteButtonListeners() {
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    isEditMode = true;
                    showEditButtons(true);
                }
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    isEditMode = true;
                    showEditButtons(true);
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition != -1) {
                    // Handle delete functionality here
                }
            }
        });
    }

    private void showEditButtons(boolean show) {
        if (show) {
            btnEdit.setVisibility(View.GONE);
            btnUpdate.setVisibility(View.VISIBLE);
            btnDelete.setVisibility(View.VISIBLE);
        } else {
            btnEdit.setVisibility(View.VISIBLE);
            btnUpdate.setVisibility(View.GONE);
            btnDelete.setVisibility(View.GONE);
        }
    }
}
