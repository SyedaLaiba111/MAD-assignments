package com.example.assignnment4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;




import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

        private EditText etName, etAddress, etPassword;
        private Button btnRegister;

        // Database helper instance
        private DatabaseHelper dbHelper;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_register);

            etName = findViewById(R.id.etName);
            etAddress = findViewById(R.id.etAddress);
            etPassword = findViewById(R.id.etPassword);
            btnRegister = findViewById(R.id.btnRegister);

            // Initialize the database helper
            dbHelper = new DatabaseHelper(this);

            btnRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String name = etName.getText().toString().trim();
                    String address = etAddress.getText().toString().trim();
                    String password = etPassword.getText().toString().trim();

                    if (!name.isEmpty() && !address.isEmpty() && !password.isEmpty()) {
                        // Insert user data into the database
                        long result = addUserToDatabase(name, address, password);

                        if (result != -1) {
                            // Registration successful
                            Toast.makeText(com.example.assignnment4.MainActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();

Intent intent = new Intent(
        MainActivity.this, LocationNoteActivity.class);
startActivity(intent);

                            // Finish the current activity so the user can't go back to it
                            finish();
                        } else {
                            // Registration failed
                            Toast.makeText(com.example.assignnment4.MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Display an error message if any field is empty
                        Toast.makeText(com.example.assignnment4.MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }

        // Method to add user data to the database
        private long addUserToDatabase(String name, String address, String password) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_NAME, name);
            values.put(DatabaseHelper.COLUMN_ADDRESS, address);
            values.put(DatabaseHelper.COLUMN_PASSWORD, password);
            long result = db.insert(DatabaseHelper.TABLE_USERS, null, values);
            db.close();
            return result;
        }
    }
