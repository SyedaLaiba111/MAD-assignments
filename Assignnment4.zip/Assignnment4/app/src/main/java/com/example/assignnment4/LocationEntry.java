package com.example.assignnment4;
import android.graphics.Bitmap;

public class LocationEntry {


        private String name;
        private String description;
        private Bitmap picture;

        public LocationEntry(String name, String description, Bitmap picture) {
            this.name = name;
            this.description = description;
            this.picture = picture;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Bitmap getPicture() {
            return picture;
        }

        public void setPicture(Bitmap picture) {
            this.picture = picture;
        }
    }
